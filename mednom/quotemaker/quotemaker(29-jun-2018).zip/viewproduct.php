<?php
//include('../connection2.php');
include_once 'lib/dbfunctionjugal.php';
$val1=$_REQUEST['val1'];
if($val1!="")
{
	$multiple_data = get_multiple_productprice_bysku($val1);
	
		// if(count($multiple_data) > 1){
		// 	echo "<script> 
		// 		 swal({title : '<h4>Product Has Multiple Price</h4>";
		// 		foreach($multiple_data as $row){ 
		// 			echo "<p>".$row['sku']." : &nbsp;&nbsp;&nbsp; $ <a id=\"".$row['final_inr']."\" onclick=\"changeValue(this)\" >".$row['final_inr']."</a></p>"; 
		// 		} 
		// 	echo "',html:'You can use bold text</br>and other HTML tags'}); </script>";
		// } 
	
	$proattributes = get_product_attributes($val1);
	$proattribute = json_decode($proattributes['specifications']);
	//$optattribute = $proattributes['accessories_optional'];
	foreach ($proattribute as $key => $attr1) {
		if ($attr1) {
			echo  $key . " : ";
			if (is_object($attr1)){
				foreach ($attr1 as $n => $n_spec) {
					if ($n_spec) {
						echo "\n"."\t".$n . " : ".$n_spec. "";
					}
				}
				echo "\n";
			}else{
				$attr1 = preg_replace('/(<[^>]*) style=("[^"]+"|\'[^\']+\')([^>]*>)/i', '$1$3',$attr1);
				echo htmlentities($attr1) ."\n";
			}
		}                                   
	}
	if(!empty($proattributes['rotor_selection'])){
		$value1 ="<h4 class=\"text-danger\">Mention : Rotor</h4>".$proattributes['rotor_selection']."<br><br>"; 
		//$value1 = preg_replace('/(<[^>]*) style=("[^"]+"|\'[^\']+\')([^>]*>)/i', '$1$3',$value1);
	}	
	if(!empty($proattributes['adapter'])){	
		$value2 = "<h4 class=\"text-danger\">Mention : Adapter</h4>".$proattributes['adapter']."<br><br>"; 
		//$value2 = preg_replace('/(<[^>]*) style=("[^"]+"|\'[^\']+\')([^>]*>)/i', '$1$3',$value2); 
	}
	if(!empty($proattributes['pump_head_and_tubing'])){	
		$value3 = "<h4 class=\"text-danger\">Mention : Pump Head And Tubing</h4>".$proattributes['pump_head_and_tubing']."<br><br>"; 
		//$value2 = preg_replace('/(<[^>]*) style=("[^"]+"|\'[^\']+\')([^>]*>)/i', '$1$3',$value2); 
	}
	if(!empty($value1) || !empty($value2) || !empty($value3)){
		$value  = "<p class=\"text-center\">Please Copy Paste The Required Subparts !</p><br>
					<div class=\"text-center\">"
						.(!empty($value1) ? $value1 : '').""
						.(!empty($value2) ? $value2 : '').""
						.(!empty($value3) ? $value3 : '')
					."</div>";       
		echo "<script>bootbox.alert({title:'Please Mention Product Sub Part',message:'".str_replace(array("\r","\n"),'',$value)."',size:'large'});</script>";
	}
}
?>  