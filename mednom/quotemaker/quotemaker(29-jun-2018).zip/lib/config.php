<?php
$host = 'localhost';
$dbname = 'agrosupe_labtron_com';
$username = 'agrosupe_labsear';
$password = 'nGIe5om0EDZq';
$dsn = "mysql:host=$host;dbname=$dbname";
//$libpath = "/linkupdate";
$conn = mysqli_connect($host,$username,$password,$dbname);
?>